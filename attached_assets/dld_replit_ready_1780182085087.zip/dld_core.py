"""
dld_core.py
-----------
Core physics engine for Deterministic Lateral Displacement (DLD)
microfluidic cell sorting simulation.

Based on:
  - Davis formula: Dc = 1.4 * G * N^(-0.48)
  - Zigzag vs bump mode particle trajectory modeling
  - Steric interaction model with pillar arrays
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.colors import to_rgba
import io, base64, json


# ── Constants ────────────────────────────────────────────────────────────────

# Typical cell diameters (micrometers) for reference
CELL_LIBRARY = {
    "Red blood cell":       8.0,
    "White blood cell":    12.0,
    "Circulating tumor cell": 16.0,
    "Platelet":             2.5,
    "Custom A":             6.0,
    "Custom B":            14.0,
}

COLOR_BUMP    = "#E24B4A"   # red  – large particles (bump mode)
COLOR_ZIGZAG  = "#378ADD"   # blue – small particles (zigzag mode)
COLOR_PILLAR  = "#B4B2A9"
COLOR_BG      = "#F8F8F6"


# ── Core Physics ─────────────────────────────────────────────────────────────

def critical_diameter(G: float, N: int) -> float:
    """
    Davis empirical formula for DLD critical diameter.
    Dc = 1.4 * G * N^(-0.48)

    Parameters
    ----------
    G : float  – gap between adjacent pillars (µm)
    N : int    – array period (rows before array repeats)

    Returns
    -------
    Dc : float – critical diameter (µm)
    """
    return 1.4 * G * (N ** -0.48)


def particle_mode(diameter: float, Dc: float) -> str:
    """Return 'bump' if diameter >= Dc, else 'zigzag'."""
    return "bump" if diameter >= Dc else "zigzag"


def sorting_efficiency(d1: float, d2: float, G: float, N: int) -> dict:
    """
    Compute separation metrics for two particle populations.

    Returns a dict with Dc, modes, lateral displacement difference,
    and a normalised efficiency score 0-100.
    """
    Dc   = critical_diameter(G, N)
    m1   = particle_mode(d1, Dc)
    m2   = particle_mode(d2, Dc)
    separated = m1 != m2

    # Lateral displacement per unit length (simplified linear model)
    # bump mode: lateral shift = G/N per row
    # zigzag mode: lateral shift ≈ 0 (follows streamlines)
    lateral_bump   = G / N          # µm per row
    lateral_zigzag = 0.0

    ld1 = lateral_bump if m1 == "bump" else lateral_zigzag
    ld2 = lateral_bump if m2 == "bump" else lateral_zigzag
    delta_ld = abs(ld1 - ld2)

    # Efficiency: how far apart are the two particles from Dc, normalised
    margin1 = abs(d1 - Dc) / Dc
    margin2 = abs(d2 - Dc) / Dc
    efficiency = min(100, round((margin1 + margin2) * 50, 1)) if separated else 0.0

    return {
        "Dc":          round(Dc, 2),
        "mode_p1":     m1,
        "mode_p2":     m2,
        "separated":   separated,
        "delta_ld":    round(delta_ld, 3),
        "efficiency":  efficiency,
        "lateral_d1":  round(ld1, 3),
        "lateral_d2":  round(ld2, 3),
    }


# ── Trajectory Simulation ────────────────────────────────────────────────────

def simulate_trajectory(
    diameter: float,
    G: float,
    N: int,
    n_rows: int = 20,
    pillar_radius: float = None,
) -> np.ndarray:
    """
    Simulate (x, y) trajectory of a single particle through a DLD array.

    The array has pillars at staggered positions. Each row is offset
    laterally by G/N relative to the previous row.

    Parameters
    ----------
    diameter    : particle diameter (µm)
    G           : gap between pillars (µm)
    N           : array period
    n_rows      : number of pillar rows to traverse
    pillar_radius : pillar radius (µm); defaults to G*0.4

    Returns
    -------
    xy : np.ndarray shape (n_rows+1, 2) – (x, y) positions in µm
    """
    if pillar_radius is None:
        pillar_radius = G * 0.4

    Dc   = critical_diameter(G, N)
    mode = particle_mode(diameter, Dc)

    # Row spacing = pillar_diameter + G
    row_pitch = 2 * pillar_radius + G
    # Column spacing (same)
    col_pitch = row_pitch

    # Lateral offset per row (stagger)
    row_offset = col_pitch / N

    positions = np.zeros((n_rows + 1, 2))
    x, y = 0.0, 0.0  # start at origin

    for i in range(n_rows):
        # Move downstream one row
        y += row_pitch

        if mode == "bump":
            # Particle deflects laterally by one gap per N rows
            # (one full bump per period)
            x += row_offset
        else:
            # Zigzag: particle follows local streamline, no net lateral drift
            # Small oscillation but zero net displacement
            x += row_offset if (i % N) < (N // 2) else -row_offset

        positions[i + 1] = [x, y]

    return positions


def geometry_sweep(
    d1: float,
    d2: float,
    G_range: tuple = (5, 50),
    N_range: tuple = (2, 12),
    n_G: int = 15,
    n_N: int = 6,
) -> dict:
    """
    Sweep pillar gap G and array period N, compute sorting efficiency
    for particle pair (d1, d2) at each combination.

    Returns arrays suitable for heatmap plotting.
    """
    G_vals = np.linspace(G_range[0], G_range[1], n_G)
    N_vals = np.arange(N_range[0], N_range[1] + 1)

    eff_matrix = np.zeros((len(N_vals), len(G_vals)))
    Dc_matrix  = np.zeros_like(eff_matrix)

    for i, N in enumerate(N_vals):
        for j, G in enumerate(G_vals):
            res = sorting_efficiency(d1, d2, G, int(N))
            eff_matrix[i, j] = res["efficiency"]
            Dc_matrix[i, j]  = res["Dc"]

    best_idx = np.unravel_index(np.argmax(eff_matrix), eff_matrix.shape)
    best = {
        "G": round(float(G_vals[best_idx[1]]), 2),
        "N": int(N_vals[best_idx[0]]),
        "efficiency": float(eff_matrix[best_idx]),
        "Dc": round(float(Dc_matrix[best_idx]), 2),
    }

    return {
        "G_vals":     G_vals.tolist(),
        "N_vals":     N_vals.tolist(),
        "eff_matrix": eff_matrix.tolist(),
        "Dc_matrix":  Dc_matrix.tolist(),
        "best":       best,
    }


# ── Plotting Helpers ──────────────────────────────────────────────────────────

def _fig_to_b64(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=130, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    buf.seek(0)
    return base64.b64encode(buf.read()).decode()


def plot_trajectories(
    d1: float, d2: float,
    G: float, N: int,
    label1: str = "Particle A",
    label2: str = "Particle B",
    n_rows: int = 18,
) -> str:
    """
    Plot trajectories of two particle types through the DLD array.
    Returns base64-encoded PNG.
    """
    pillar_r = G * 0.4
    row_pitch = 2 * pillar_r + G
    col_pitch = row_pitch
    n_cols    = 6

    traj1 = simulate_trajectory(d1, G, N, n_rows, pillar_r)
    traj2 = simulate_trajectory(d2, G, N, n_rows, pillar_r)

    fig, ax = plt.subplots(figsize=(7, 8), facecolor=COLOR_BG)
    ax.set_facecolor(COLOR_BG)

    # Draw pillar array
    for row in range(n_rows + 1):
        offset = (row % N) * (col_pitch / N)
        for col in range(-1, n_cols + 1):
            cx = col * col_pitch + offset
            cy = row * row_pitch
            circle = plt.Circle((cx, cy), pillar_r,
                                 color=COLOR_PILLAR, zorder=2, alpha=0.85)
            ax.add_patch(circle)

    # Draw trajectories
    ax.plot(traj1[:, 0], traj1[:, 1],
            color=COLOR_ZIGZAG, lw=2.5, zorder=4,
            label=f"{label1} (ø{d1}µm)", marker="o",
            markersize=4, markevery=2)
    ax.plot(traj2[:, 0], traj2[:, 1],
            color=COLOR_BUMP, lw=2.5, zorder=4,
            label=f"{label2} (ø{d2}µm)", marker="s",
            markersize=4, markevery=2)

    Dc = critical_diameter(G, N)
    ax.set_title(
        f"DLD Trajectory Simulation\nG={G}µm  N={N}  Dc={Dc:.1f}µm",
        fontsize=12, pad=10, color="#2C2C2A"
    )
    ax.set_xlabel("Lateral position (µm)", fontsize=10)
    ax.set_ylabel("Downstream position (µm)", fontsize=10)
    ax.legend(loc="upper left", fontsize=9, framealpha=0.9)
    ax.set_xlim(-col_pitch, n_cols * col_pitch)
    ax.set_ylim(-row_pitch, (n_rows + 1) * row_pitch)
    ax.set_aspect("equal")
    ax.tick_params(labelsize=8)
    for spine in ax.spines.values():
        spine.set_color("#D3D1C7")

    plt.tight_layout()
    b64 = _fig_to_b64(fig)
    plt.close(fig)
    return b64


def plot_heatmap(sweep_data: dict, d1: float, d2: float) -> str:
    """
    Plot efficiency heatmap over G-N parameter space.
    Returns base64-encoded PNG.
    """
    eff  = np.array(sweep_data["eff_matrix"])
    G_vals = np.array(sweep_data["G_vals"])
    N_vals = np.array(sweep_data["N_vals"])
    best   = sweep_data["best"]

    fig, ax = plt.subplots(figsize=(7, 4.5), facecolor=COLOR_BG)
    ax.set_facecolor(COLOR_BG)

    im = ax.imshow(
        eff, aspect="auto", origin="lower",
        extent=[G_vals[0], G_vals[-1], N_vals[0], N_vals[-1]],
        cmap="RdYlGn", vmin=0, vmax=100, interpolation="bilinear"
    )
    cb = plt.colorbar(im, ax=ax, label="Sorting efficiency (%)")
    cb.ax.tick_params(labelsize=8)

    # Mark best point
    ax.plot(best["G"], best["N"], "w*", markersize=14, zorder=5,
            label=f"Best: G={best['G']}µm, N={best['N']} → {best['efficiency']:.0f}%")

    ax.set_xlabel("Pillar gap G (µm)", fontsize=10)
    ax.set_ylabel("Array period N", fontsize=10)
    ax.set_title(
        f"Sorting efficiency: ø{d1}µm vs ø{d2}µm particles",
        fontsize=11, pad=8, color="#2C2C2A"
    )
    ax.legend(loc="upper right", fontsize=8, framealpha=0.9)
    ax.tick_params(labelsize=8)
    for spine in ax.spines.values():
        spine.set_color("#D3D1C7")

    plt.tight_layout()
    b64 = _fig_to_b64(fig)
    plt.close(fig)
    return b64


def plot_dc_vs_G(N_values: list, G_range: tuple = (2, 60)) -> str:
    """
    Plot critical diameter vs pillar gap for several N values.
    Returns base64-encoded PNG.
    """
    G_arr = np.linspace(G_range[0], G_range[1], 200)
    colors = ["#378ADD", "#E24B4A", "#1D9E75", "#BA7517", "#534AB7", "#D85A30"]

    fig, ax = plt.subplots(figsize=(7, 4), facecolor=COLOR_BG)
    ax.set_facecolor(COLOR_BG)

    for idx, N in enumerate(N_values):
        Dc_arr = [critical_diameter(G, N) for G in G_arr]
        ax.plot(G_arr, Dc_arr,
                color=colors[idx % len(colors)],
                lw=2, label=f"N = {N}")

    ax.set_xlabel("Pillar gap G (µm)", fontsize=10)
    ax.set_ylabel("Critical diameter Dc (µm)", fontsize=10)
    ax.set_title("Critical diameter vs pillar gap\n(Davis formula: Dc = 1.4·G·N⁻⁰·⁴⁸)",
                 fontsize=11, pad=8, color="#2C2C2A")
    ax.legend(fontsize=9, framealpha=0.9)
    ax.grid(True, alpha=0.3, color="#D3D1C7")
    ax.tick_params(labelsize=8)
    for spine in ax.spines.values():
        spine.set_color("#D3D1C7")

    plt.tight_layout()
    b64 = _fig_to_b64(fig)
    plt.close(fig)
    return b64


# ── Quick CLI demo ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 55)
    print("  DLD Core Physics Demo")
    print("=" * 55)

    G, N = 20.0, 5
    d1, d2 = 8.0, 12.0   # RBC vs WBC (µm)

    Dc = critical_diameter(G, N)
    print(f"\nGeometry:  G={G}µm  N={N}")
    print(f"Critical diameter Dc = {Dc:.2f} µm")

    res = sorting_efficiency(d1, d2, G, N)
    print(f"\nParticle 1 (ø{d1}µm): {res['mode_p1']} mode")
    print(f"Particle 2 (ø{d2}µm): {res['mode_p2']} mode")
    print(f"Separated:  {res['separated']}")
    print(f"Efficiency: {res['efficiency']}%")

    print("\nRunning geometry sweep…")
    sweep = geometry_sweep(d1, d2)
    b = sweep["best"]
    print(f"Best config → G={b['G']}µm  N={b['N']}  "
          f"Dc={b['Dc']}µm  efficiency={b['efficiency']}%")

    print("\nSaving trajectory plot → trajectory_demo.png")
    b64 = plot_trajectories(d1, d2, G, N,
                            label1="Red blood cell",
                            label2="White blood cell")
    with open("trajectory_demo.png", "wb") as f:
        f.write(base64.b64decode(b64))

    print("Saving heatmap → heatmap_demo.png")
    b64h = plot_heatmap(sweep, d1, d2)
    with open("heatmap_demo.png", "wb") as f:
        f.write(base64.b64decode(b64h))

    print("Saving Dc curve → dc_curve_demo.png")
    b64d = plot_dc_vs_G([3, 5, 7, 10])
    with open("dc_curve_demo.png", "wb") as f:
        f.write(base64.b64decode(b64d))

    print("\nDone.")
