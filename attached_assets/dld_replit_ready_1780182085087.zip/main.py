"""
main.py — Replit entry point
Just hit the green RUN button. That's it.
"""

from flask import Flask, render_template, request, jsonify
from dld_core import (
    critical_diameter, sorting_efficiency,
    geometry_sweep, plot_trajectories,
    plot_heatmap, plot_dc_vs_G,
    CELL_LIBRARY,
)

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html", cell_library=CELL_LIBRARY)


@app.route("/api/analyze", methods=["POST"])
def analyze():
    data = request.json
    try:
        d1 = float(data["d1"])
        d2 = float(data["d2"])
        G  = float(data["G"])
        N  = int(data["N"])
        l1 = data.get("label1", "Particle A")
        l2 = data.get("label2", "Particle B")

        res  = sorting_efficiency(d1, d2, G, N)
        traj = plot_trajectories(d1, d2, G, N, l1, l2)

        return jsonify({"ok": True, "result": res, "trajectory": traj})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/api/sweep", methods=["POST"])
def sweep():
    data = request.json
    try:
        d1 = float(data["d1"])
        d2 = float(data["d2"])

        sweep_data = geometry_sweep(d1, d2)
        heatmap    = plot_heatmap(sweep_data, d1, d2)

        return jsonify({"ok": True, "sweep": sweep_data, "heatmap": heatmap})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/api/dc_curve", methods=["POST"])
def dc_curve():
    data = request.json
    try:
        N_values = [int(n) for n in data.get("N_values", [3, 5, 7, 10])]
        img = plot_dc_vs_G(N_values)
        return jsonify({"ok": True, "image": img})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=False)
